hh = 18
mm = 12

import os
import wget
import time

while(True):
    for i in range(0, 240):
        lastmm = mm
        lasthh = hh
        mm = mm + 6
        if mm >= 60:
            mm = mm - 60
            hh += 1
        url = f"https://www.hko.gov.hk/wxinfo/radars/rad_064_png/2d064nradar_20230901{hh:02d}{mm:02d}.jpg"
        basefilename = f"2d064nradar_20230901{hh:02d}{mm:02d}.jpg"
        if not os.path.exists(basefilename):
            print('\n', url)
            try:
                filename = wget.download(url)
            except:
                print("err", url)
                break
    print("done loop.. sleeping for 180 secs")
    time.sleep(180)
    mm = lastmm
    hh = lasthh
